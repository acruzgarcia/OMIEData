import pandas as pd


class OMIEFileReader:

    @staticmethod
    def get_keys() -> list:
        pass

    def data_generator(self, filename: str) -> pd.DataFrame:
        pass
