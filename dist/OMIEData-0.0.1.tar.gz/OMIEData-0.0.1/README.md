# Package OMIEData
Package to download electricity time series (prices and demand) from https://www.omie.es/

# To install the package from the command line:
python -m pip install git+https://github.com/acruzgarcia/OMIEData

# Example use case:
File 'Example.py' describes a use case to download and process, i.e create a dataframe, with prices and demands.

Enjoy!.
