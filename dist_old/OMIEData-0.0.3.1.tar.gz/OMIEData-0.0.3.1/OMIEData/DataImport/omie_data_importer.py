import pandas as pd


class OMIEDataImporter:

    def read_to_dataframe(self, verbose=False) -> pd.DataFrame:
        pass
