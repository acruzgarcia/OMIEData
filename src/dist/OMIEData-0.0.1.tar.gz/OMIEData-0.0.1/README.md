# Package OMIEData-acruz-mmora
Package to download electricity time series from https://www.omie.es/